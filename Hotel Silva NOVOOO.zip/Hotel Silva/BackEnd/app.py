import os
from flask import Flask, send_from_directory
import openpyxl
from datetime import (s
    datetime,
)



DIR_BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DIR_FRONTEND = os.path.join(DIR_BASE, "Frontend")
DIR_STATIC = os.path.join(DIR_BASE, "Static")

app = Flask(__name__, static_folder=DIR_STATIC, static_url_path="/Static")

@app.route("/")
def home():
    return send_from_directory(DIR_FRONTEND, "index.html")

@app.route("/consulta")
def consultar_page():
    return send_from_directory(DIR_FRONTEND, "consulta.html")

@app.route("/alterar")
def alterar_page():
    return send_from_directory(DIR_FRONTEND, "alterar.html")


if __name__ == "__main__":
    print("DIRETORIO_BASE:", DIR_BASE)
    print("DIRETORIO_FRONTEND:", DIR_FRONTEND)
    print("DIRETORIO_STATIC:", DIR_STATIC)
    app.run(debug=True)

import os
from flask import Flask, request, send_from_directory
import openpyxl
from datetime import (
    datetime,
)



DIR_BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

DIR_FRONTEND = os.path.join(DIR_BASE, "Frontend")

DIR_STATIC = os.path.join(DIR_BASE, "Static")

DIR_DB = os.path.join(DIR_BASE, "db")

EXCEL_FILE = os.path.join(DIR_DB, "clientes.xlsx")



COLUNAS = [
    "ID",
    "Nome",
    "CPF",
    "Email",
    "Telefone",
    "Endereço",
    "Observações",
    "Data Cadastro",
]

def init_excel():
    if not os.path.exists(DIR_DB):
        os.makedirs(DIR_DB)
    
    if not os.path.exists(EXCEL_FILE):
        workbook = openpyxl.Workbook()
        sheet = workbook.active
        sheet.title = "Clientes"
        sheet.append(COLUNAS)
        workbook.save(EXCEL_FILE)

app = Flask(__name__, static_folder=DIR_STATIC, static_url_path="/Static")

@app.route("/")
def home():
    return send_from_directory(DIR_FRONTEND, "index.html")

@app.route("/consulta")
def consultar_page():
    return send_from_directory(DIR_FRONTEND, "consulta.html")

@app.route("/alterar")
def alterar_page():
    return send_from_directory(DIR_FRONTEND, "alterar.html")

@app.route("/assets/<path:filename>")
def assets(filename):
    return send_from_directory("../frontend/assets", filename)

@app.route("/cadastrar", methods=["POST"])
def cadastrar_cliente():
    try:
        data = request.json
        required_fields = ["nome", "cpf", "email", "telefone", "endereço"]
        if not all(field in data and data[field] for field in required_fields):
            return (
                jsonify(
                    {
                        "status": "error",
                        "message": "Todos os campos obrigatórios devem ser preenchidos.",
                    }
                ),
                400,
            )
        workbook= openpyxl.load_workbook(EXCEL_FILE)
        sheet = workbook.active
        last_id = 0
        if sheet.max_row > 1:
            last_id = sheet.cell(row=sheet.max_row, column=1).value or 0
        new_id = last_id + 1

        novo_cliente = []



if __name__ == "__main__":
    print("DIRETORIO_BASE:", DIR_BASE)
    print("DIRETORIO_FRONTEND:", DIR_FRONTEND)
    print("DIRETORIO_STATIC:", DIR_STATIC)
    init_excel()
    app.run(debug=True)


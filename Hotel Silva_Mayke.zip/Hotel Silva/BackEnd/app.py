import os
from flask import Flask, send_from_directory

DIR_BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DIR_FRONTEND = os.path.join(DIR_BASE, "Frontend")
DIR_STATIC = os.path.join(DIR_BASE, "Static")

app = Flask(__name__, static_folder=DIR_STATIC, static_url_path="/Static")

@app.route("/")
def home():
    return send_from_directory(DIR_FRONTEND, "index.html")

@app.route("/consulta")
def consultar_page():
    return send_from_directory(DIR_FRONTEND, "consulta.html")

@app.route("/alterar")
def alterar_page():
    return send_from_directory(DIR_FRONTEND, "alterar.html")


if __name__ == "__main__":
    print("BASE_DIR:", DIR_BASE)
    print("FRONTEND_DIR:", DIR_FRONTEND)
    print("STATIC_DIR:", DIR_STATIC)
    app.run(debug=True)

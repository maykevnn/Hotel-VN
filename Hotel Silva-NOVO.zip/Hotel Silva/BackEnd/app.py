import os
from flask import Flask, send_from_directory

DIR_BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DIR_FRONTEND = os.path.join(DIR_BASE, "Frontend")
DIR_STATIC = os.path.join(DIR_BASE, "Static")

app = Flask(__name__, static_folder=DIR_STATIC, static_url_path="/" + DIR_STATIC)

@app.route("/")
def home():
    return 


app.run()